package com.example.CompanyMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
